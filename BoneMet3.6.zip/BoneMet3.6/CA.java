//Modelling of Bone Modelling Unit by Arturo Araujo, Leah Cook, Conor Lynch and David Basanta (arturo@cancerevo.org)
//Released under Apache 2.0 License, Version 2.0 requiring preservation of the copyright notice and disclaimer. 
//License  allows the user of the software the freedom to use the software for for academic purposes but commercial use is prohibited.
//Please cite as: Araujo, A., Cook, L. M., Lynch, C. C., & Basanta, D. (2014). An integrated computational model of the bone microenvironment in bone-metastatic prostate cancer. Cancer research, 74(9), 2391-2401.
//To run, compile Vis.java and run it

import java.io.*;
import java.util.*;
import static java.lang.Math.*;

public class CA {
	public static String version="1 May 2013";
	MersenneTwisterFast random;
	public int mag=2; //Why wont it let me set it at 1?!
    public int drug=0;
    
//Used as seed for random number generator
    int seed=7;
    
//Define the space
    int[][] age=null;
	Bag cellList=null; // Used in the iterateCells method. Defined here for performance issues
	boolean finishedRun=false;
	
	int sizeX = 200; // Size of the system lattice
	int sizeY = 150; //Check it coincides with Vis.java!
	int timestep=0; // Current Number of timesteps in the simulation
    int boneLimit=25;
    
    
//Define Fields
    boolean[][] canopyCrossing;
    boolean[][] pOBRANKL;
    boolean[][] boneDestroyed;
    boolean[][] boneRemodeled;
    boolean[][] tumourTGFB;
    int [][] Timer=null; //Timer for each time step
	int [][] Cells=null; // Cells  and the cell type
    // 0 -> Marrow
    // 1 -> pOB
    // 2 -> aOB
    //  3 -> pOC
    // 4 -> aOC
    // 5 -> MSCs
    // 6 -> TRPs
    // 7 -> TRs
    // 8 -> TN
    // 9 -> Bone
    //10 -> Canopy
    
    //TGFB Parameters
	float [][] TGFB=null; // Level of TGF in each CA site
	float tgfbDecayRate = 0.01f;
    float tgfbDetect = 0.000001f;
	float boneTGFBreleaseRate = 1.0f;
    float cellTGFBreleaseRate = 0.0001f;
	float kDt= 0.03f;
    float totalTGFB=0f;
    
    //TGFB detection by Cells parameters
    
    float lowTGFB= 0.00001f;
    float medTGFB= 0.0001f;
    float highTGFB= 0.001f;
    
    
    //Bone Remodeling Field Parameters
    float[][] boneRemodeling; //Field for nutrients released & estrogen
    float remodelingDecayRate = 0.01f;
    float remodelingDetect = 0.00001f;
	float remodelingreleaseRate = 1.0f;
	float kDtremodeling= 0.03f;
    float totalRemodeling=0f;
    
    
    //RANKL field parameters
    float[][] RANKL; //Field for RANKL release by pOBs
    float RANKLDecayRate = 0.01f;
    float RANKLDetect = 0.00001f;
	float RANKLreleaseRate = 1.0f; //used in normal case
	float RANKLkDt= 0.03f;
    float RANKLtotal=0f;
    
    //TGFB detection by Cells parameters
    
    float lowRANKL= 0.00001f;
    float medRANKL= 0.0001f;
    float highRANKL= 0.001f;
    
    //Time Parameters
    //6 mins= 1 timestep
    //1 hour= 10 ts
    
    int day1= 240; //division of pOBs and thus pOCs
    int day4= 960;
    int day14= 3840; // lifespan of pOCs and pOBs
    int day21= 5040; // pOb differentiation time
    int day90= 21600; //lifespan of OBs && time of pOB release
    
    //OsteoBlast parameters
    int pOBborn=10*day90; //For MSCs
    int pOBdiv=day1;
    int pOBdeath=day14;
    int timerOB=10;
    int formation=720;
    
    //OsteoClast parameters
    int pOCdeath=day14;
    int aOCdeath=day14;
    int aOBdeath=75*day1;
    int resorption=240; //not really sure about this. Also used for formation.
    int canopy=0; //just a counter. the actual canopy usually starts with 107.
    
    //Tumor Parameters
    int tnDiv=2*day1;
    int mscRec=150000; // chance of MSC recruitment per tumour cell
	
	// measurament and statistics
	int births=0;
	int deaths=0;

	public CA ()
	{
		int time = (int) System.currentTimeMillis();
		random = new MersenneTwisterFast (seed);
		reset();
	}
    

	
	
	final int distance (int x, int y, int i, int j)
	{
		double dis=Math.sqrt((x-i)*(x-i)+(y-j)*(y-j));
		return (int)Math.round(dis);
	}

	final int[] convertCoordinates(int x, int y)
       {
               // This method converts the coordinates so they take on account
               // the boundaries of the lattice

               if (x < 0) x = sizeX - 1;
               else if (x > sizeX - 1) x = 0;
               if (y < 0) y = sizeY - 1;
               else if (y > sizeY - 1) y = 0;
               int[] result = new int[2];
               result[0] = x; result[1] = y;
               return result;
       }
    
    
    final int[] convertCoordinatesNoB(int x, int y)
    {
        // This method converts the coordinates so they take on account
        // the boundaries of the lattice
        
        if (x < 0) x = 0;
        else if (x > sizeX - 1) x = sizeX - 1;
        if (y < 0) y = 0;
        else if (y > sizeY - 1) y = sizeY - 1;
        int[] result = new int[2];
        result[0] = x; result[1] = y;
        return result;
    }
	
	public void nextTimeStep () 
	{
		births=0;
		deaths=0;
        int pOB=0;
        int aOB=0;
        int pOC=0;
        int aOC=0;
        int MSC=0;
        int TRP=0;
        int TR=0;
        int TN=0;
        int bone=0;
        

       
//Iterate the Fields
        for (int times=0;times<3;times++) iterateTGFB();      
        for (int times=0;times<3;times++) iterateRemodeling();        
        for (int times=0;times<3;times++) iterateRANKL();
        iterateCells();
        
//Check for Xgeva
        
        /*if (timestep==50000)
        {RANKLreleaseRate=0;}*/
        
        
//Initial TGFB busrt (5 days)
        if(timestep<=5*day1){
            for (int i=0;i<10;i++) {
            boneDestroyed[-4-i+sizeX/2][boneLimit-1]= true;
        }};
		
		// Counter for cells
		int totalCells=0;
        totalTGFB=0f;
        canopy=0;
		for (int i=0;i<sizeX;i++) {
			for (int j=0;j<sizeY;j++) {
                totalTGFB+=TGFB[i][j];
				if (Cells[i][j]>0) {
					totalCells++;
                    if (Cells[i][j]==1) pOB++;
                    else if (Cells[i][j]==2) aOB++;
                    else if (Cells[i][j]==3) pOC++;
                    else if (Cells[i][j]==4) aOC++;
                    else if (Cells[i][j]==5) MSC++;
                    else if (Cells[i][j]==6) TRP++;
                    else if (Cells[i][j]==7) TR++;
                    else if (Cells[i][j]==8) TN++;
                    else if (Cells[i][j]==9) bone++;
                    else if (Cells[i][j]==10) canopy++;
				}
            }
        }
		//Actual time step increase (6mins)
		timestep++;
//Count cells each time step
       System.out.println (pOB+" "+aOB+" "+pOC+" "+aOC+" "+MSC+" "+TRP+" "+TR+" "+TN+" "+bone+" "+canopy+" "+totalTGFB);
        //Write to file
        try {
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("exp"+seed+".txt", true)));
            out.println(pOB+" "+aOB+" "+pOC+" "+aOC+" "+MSC+" "+TRP+" "+TR+" "+TN+" "+bone+" "+canopy+" "+totalTGFB);
            out.close();
        } catch (IOException e) {
            //oh noes!
        }
        
       	}

	
	void reset ()
	{
        //Fields
		Cells = new int [sizeX][sizeY];
        TGFB = new float [sizeX][sizeY];
        age = new int [sizeX][sizeY];
        Timer = new int [sizeX][sizeY];
        boneRemodeling=new float[sizeX][sizeY];
        RANKL = new float [sizeX][sizeY];
       //Flags
		boneDestroyed=new boolean[sizeX][sizeY];
        boneRemodeled=new boolean[sizeX][sizeY];
       // activeByTGFB=new boolean[sizeX][sizeY];
        
       // activeOC=new boolean[sizeX][sizeY];
        pOBRANKL=new boolean[sizeX][sizeY];
        canopyCrossing=new boolean[sizeX][sizeY];
        tumourTGFB=new boolean[sizeX][sizeY];

        
        //Timer Starts at 0
        for (int i=0;i<sizeX;i++)
        	for (int j=0;j<sizeY;j++) Timer[i][j]=0;
        
        /*No OC activation at the start
        for (int i=0;i<sizeX;i++)
        	for (int j=0;j<sizeY;j++) activeOC[i][j]=false;*/
        
        //No cannopy crossing at the start
        for (int i=0;i<sizeX;i++)
        	for (int j=0;j<sizeY;j++) canopyCrossing[i][j]=false;
                
        //the canopy (Pink)        
        for (int i=0; i<100; i++) {
            Cells[i+sizeX/4][boneLimit+2]=10;
            age[i+sizeX/4][boneLimit+2]=0;}        
        for (int i=0; i<4; i++) {
            Cells[sizeX/4][boneLimit+2-i]=10;
            age[sizeX/4][boneLimit+2-i]=0;}        
        for (int i=0; i<4; i++) {
            Cells[3*sizeX/4][boneLimit+2-i]=10;
            age[3*sizeX/4][boneLimit+2-i]=0;}
                
        // Bone Cells (Gray)
		for (int i=0;i<sizeX;i++) {
			for (int j=0;j<boneLimit-1;j++)
            {Cells[i][j]=9;
			age[i][j]=random.nextInt(14);
            }
		}
        
       // initial TGFB burst
        for (int i=0;i<10;i++) {            
            boneDestroyed[-4-i+sizeX/2][boneLimit-1]= true; }        
        
		// 1 MSCs (Yellow)       
        Cells[sizeX/3][boneLimit]=5;
        age[sizeX/3][boneLimit]=pOBborn-1;
        
        // 1 Tumour cell of each
        
        Cells[sizeX/2-8][boneLimit]=6;
        age[sizeX/2-8][boneLimit]=0;
        /*Cells[sizeX/2-6][boneLimit]=7;
        age[sizeX/2-6][boneLimit]=random.nextInt(3840);
        Cells[sizeX/2-4][boneLimit]=8;
        age[sizeX/2-4][boneLimit]=random.nextInt(3840);*/
        
         
	}

	public boolean iterateCells()
 	{
        //Goes through the entire list, selecting one element at a time
		if (cellList==null) cellList = new Bag (sizeX*sizeY); 
		for (int i = 0; i < sizeX; i++)
			for (int j = 0; j < sizeY; j++) {
				if (Cells[i][j] > 0)  { // All cell types have Cell > 0 
					int[] p = new int[2];
					p[0] = i; p[1] = j;
					cellList.add(p);
				}
			}
        
		while (cellList.size() != 0) {
			// Select the next lattice element at random
			int randomElemIndex=0;
			if (cellList.size()>1) randomElemIndex = random.nextInt(cellList.size()-1);
	   		int[] point = (int[])cellList.get(randomElemIndex); 
		   	int rI = point[0];
		   	int rJ = point[1];
			cellList.remove(randomElemIndex); // Remove it from the cell list
		   	int cell = Cells[rI][rJ];
            //Increase age of element
            age[rI][rJ]+=1;
            Timer[rI][rJ]=Timer[rI][rJ]+1;
	  
            
// Cell Actions
                    
// precursor Osteoblast     
            if (cell==1) {       
                pOBRANKL[rI][rJ]=true;
                //RANKL summons pOCs        
                if (RANKL[rI][rJ]>highRANKL && random.nextInt(1+(2*day1))>=(2*day1)){
                    int l=random.nextInt(sizeX-1);
                    int m=sizeY-1;
                    Cells[l][m]=3;
                    age[l][m]=0;
                }
                                
                if (age[rI][rJ]>pOBdeath){
                    //If they are 21 days old, the differentiate into aOB
                    Cells[rI][rJ]=2;
                    age[rI][rJ]=0;
                   // activeByTGFB[rI][rJ]=false;
                    pOBRANKL[rI][rJ]=false;
                    // System.out.println ("Adult OB born!");
                }
                
                //if age is less than 8 days and TGFB present, try to divide (once every day; 1 day= 240 ts)
                else if(TGFB[rI][rJ]>lowTGFB && random.nextInt(1+(2*day1))>=(2*day1) && age[rI][rJ]<7*day1) {
                    
                    int[] p = findEmptySite (rI,rJ);
                    if (Cells[p[0]][p[1]]==0) {
                        Cells[p[0]][p[1]]=1;
                        age[p[0]][p[1]]=age[rI][rJ];
                        // System.out.println ("Total TGFb OB"+totalTGFB);
                    }
                }
                
               
                else if (Timer[rI][rJ]>=timerOB) {
                   //Reset Timer
                    Timer[rI][rJ]=0;
                    //Find TGFB, move ot it
                    int[] p = seekTGFB (rI,rJ);
                                      
                        if (Cells[p[0]][p[1]]==0) {
                        Cells[p[0]][p[1]]=1;
                        age[p[0]][p[1]]=age[rI][rJ];
                       // activeByTGFB[p[0]][p[1]]=true;
                        Cells[rI][rJ]=0;
                        age[rI][rJ]=0;
                       // activeByTGFB[rI][rJ]=false;
                        }
                    
                        else {
                                // Move!
                        int[] q = findEmptySite (rI,rJ);
                        if (Cells[q[0]][q[1]]==0) {
                        Cells[q[0]][q[1]]=1;
                        Cells[rI][rJ]=0;
                        age[q[0]][q[1]]=age[rI][rJ];
                        age[rI][rJ]=0;
                      //  activeByTGFB[q[0]][q[1]]=activeByTGFB[rI][rJ];
                       // activeByTGFB[rI][rJ]=false;
                        }
                    }
                }
			}
            
            
// Adult Osteoblast (it creates bone)
			if (cell==2){
                //here -y actually is -y
                
                int[] l=convertCoordinates(rI,rJ-1);
                int[] q=findBoneCreateAlt(rI,rJ);
                int[] r=convertCoordinates(rI,rJ+1);
               
                // Are we supposed to die now of old age?
                if (age[rI][rJ]>=aOBdeath) {
                    Cells[rI][rJ]=0;
                    age[rI][rJ]=0;
                    Timer[rI][rJ]=0;
                }
                                
               /*else?*/ if (Timer[rI][rJ]>=timerOB){
                    //If there is no Bone
                    if (Cells[l[0]][l[1]]!=9){
                        int[] p=seekTGFB(rI,rJ);
                        //Take new Place
                        if (Cells[p[0]][p[1]]==0) {
                            Cells[p[0]][p[1]]=2;
                            Timer[p[0]][p[1]]=0;
                            age[p[0]][p[1]]=age[rI][rJ];
                           // activeByTGFB[p[0]][p[1]]=true;
                            Cells[rI][rJ]=0;
                            Timer[rI][rJ]=0;
                            age[rI][rJ]=0;
                          //  activeByTGFB[rI][rJ]=false;
                        }
                        
                        else {
                            // Move downwards thorugh cancer cells!
                            int[] b=findEmptySiteDownwards2(rI,rJ);
                            Cells[rI][rJ]=Cells[b[0]][b[1]];
                            int tempAge=age[b[0]][b[1]];
                            int tempTimer=Timer[b[0]][b[1]];
                            age[b[0]][b[1]]=age[rI][rJ];
                            age[rI][rJ]=tempAge;
                            Timer[rI][rJ]=tempTimer;
                            Cells[b[0]][b[1]]=2;
                            Timer[b[0]][b[1]]=0;
                            
                            //how to take this place out of the bag?
                                //Put cell in the old place
                                
                                age[rI][rJ]=tempAge;
                                Timer[rI][rJ]=tempTimer;
                            
                            }
                    }
                    
                    //If there is an OB underneath, move up? Accelerate bone growth?
                    
                    
                    /*else if (Timer[rI][rJ]<formation){
                        boneRemodeled[rI][rJ]=true;                        
                    }*/
                    
                    //If there is bone
                    else if (Timer[rI][rJ]>=formation){
                        /*int[] b=findBoneCreateAlt(rI,rJ);
                        //Take new Place
                        Cells[b[0]][b[1]]=2;
                        Timer[b[0]][b[1]]=0;
                        age[b[0]][b[1]]=age[rI][rJ];
                        //Form bone in the old place
                        Cells[rI][rJ]=9;
                        age[rI][rJ]=0;
                        Timer[rI][rJ]=0;
                        boneRemodeled[rI][rJ]=true;*/
                        
                        Cells[r[0]][r[1]]=2;
                        Timer[r[0]][r[1]]=0;
                        age[r[0]][r[1]]=age[rI][rJ];
                        Cells[rI][rJ]=9;
                        age[rI][rJ]=0;
                        Timer[rI][rJ]=0;
                        //boneRemodeled[rI][rJ]=true;
                        
                        
                        
                    }
                }
            }
		
            
//precursor Osteoclast (it seeks RANKL, bone)
			if (cell==3) {
 
                //Here -y is actually -y!
                int[] p1=convertCoordinates(rI,rJ-1);
                int[] p2=convertCoordinates(rI+1,rJ);
                int[] p3=convertCoordinates(rI-1,rJ);
                int[] p4=convertCoordinates(rI+2,rJ);
                int[] p5=convertCoordinates(rI-2,rJ);
                int[] p6=convertCoordinates(rI+3,rJ);
                int[] p7=convertCoordinates(rI-3,rJ);
                
                //System.out.println ("Canopy "+canopy);
                //System.out.println ("Total TGFb OB "+totalTGFB);
                
              //Are we supposed to die of old age?
                if ((age[rI][rJ]>=2*day1) || (rJ==1) ) {
                    // System.out.println ("age of death"+age[rI][rJ]);
                    Cells[rI][rJ]=0;
                    age[rI][rJ]=0;
                    //activeOC[rI][rJ]=false;
                }

                // If in contact with the bone check if my 6 neighbors are an Oc && TGF is low & if the canopy is half destroyed
                else if (canopy<=50 && 
                         (TGFB[rI][rJ]<highTGFB) &&
                         (RANKL[rI][rJ]>RANKLDetect) &&
                         (Cells[p1[0]][p1[1]]==9) &&
                         (Cells[p2[0]][p2[1]]==3) &&
                         (Cells[p3[0]][p3[1]]==3)&&
                         (Cells[p4[0]][p4[1]]==3) &&
                         (Cells[p5[0]][p5[1]]==3)
                         ) {
                    
                    // Differentiate into Adult OsteoClast
                    
                    Cells[rI][rJ]=4;
                    Cells[p2[0]][rJ]=4;
                    Cells[p3[0]][rJ]=4;
                    Cells[p4[0]][rJ]=4;
                    Cells[p5[0]][rJ]=4;
                    age[rI][rJ]=0;
                    age[p2[0]][rJ]=0;
                    age[p3[0]][rJ]=0;
                    age[p4[0]][rJ]=0;
                    age[p5[0]][rJ]=0;
                    
                }
                
                
                else if ((TGFB[rI][rJ]<highTGFB) &&
                         (RANKL[rI][rJ]>RANKLDetect) &&
                         (Cells[p1[0]][p1[1]]==9) &&
                         (Cells[p2[0]][p2[1]]==3) &&
                         (Cells[p3[0]][p3[1]]==3) &&
                         (Cells[p3[0]][p3[1]]==3) &&
                         (Cells[p4[0]][p4[1]]==3) &&
                         (Cells[p5[0]][p5[1]]==3) &&
                         (Cells[p6[0]][p6[1]]==3) &&
                         (Cells[p7[0]][p7[1]]==3)) {
                    
                    // Differentiate into Adult OsteoClast

                    Cells[rI][rJ]=4;
                    Cells[p2[0]][rJ]=4;
                    Cells[p3[0]][rJ]=4;
                    Cells[p4[0]][rJ]=4;
                    Cells[p5[0]][rJ]=4;
                    Cells[p6[0]][rJ]=4;
                    Cells[p7[0]][rJ]=4;
                    age[rI][rJ]=0;
                    age[p2[0]][rJ]=0;
                    age[p3[0]][rJ]=0;
                    age[p4[0]][rJ]=0;
                    age[p5[0]][rJ]=0;
                    age[p6[0]][rJ]=0;
                    age[p7[0]][rJ]=0;
                }
                 
                //If none are, seek other pOCs along the bone
                else {
                   int[] q=findEmptySiteDownwards(rI,rJ);
                    int[] r=seekRANKL(rI,rJ);
                    //if its crossing the cannopy                    
                    
                    if (Cells[q[0]][q[1]]==10){
                        canopyCrossing[q[0]][q[1]]=true;
                        Cells[q[0]][q[1]]=3;
                        age[q[0]][q[1]]=age[rI][rJ];
                        Cells[rI][rJ]=0;
                        age[rI][rJ]=0;}
                    
                    else if(canopyCrossing[rI][rJ]==true){
                        canopyCrossing[rI][rJ]=false;
                        Cells[q[0]][q[1]]=3;
                        age[q[0]][q[1]]=age[rI][rJ];
                        Cells[rI][rJ]=10;
                        age[rI][rJ]=0;}
                    
                    else if (Cells[r[0]][r[1]]==0) {
                        Cells[r[0]][r[1]]=3;
                        age[r[0]][r[1]]=age[rI][rJ];
                        
                        Cells[rI][rJ]=0;
                        age[rI][rJ]=0;}
                    
                    else if (Cells[q[0]][q[1]]==0) {
                        Cells[q[0]][q[1]]=3;
                        age[q[0]][q[1]]=age[rI][rJ];
                        
                        Cells[rI][rJ]=0;
                        age[rI][rJ]=0;}
                    
                    else {
                        // Move downwards thorugh cancer cells!
                        int[] b=findEmptySiteDownwards2(rI,rJ);
                        Cells[rI][rJ]=Cells[b[0]][b[1]];
                        int tempAge=age[b[0]][b[1]];
                        int tempTimer=Timer[b[0]][b[1]];
                        age[b[0]][b[1]]=age[rI][rJ];
                        age[rI][rJ]=tempAge;
                        Timer[rI][rJ]=tempTimer;
                        Cells[b[0]][b[1]]=3;
                        Timer[b[0]][b[1]]=0;
                        
                        //how to take this place out of the bag?
                        //Put cell in the old place
                        
                        age[rI][rJ]=tempAge;
                        Timer[rI][rJ]=tempTimer;
                    }
                }
			}

// Adult Osteoclast
            if(cell==4 ) {
                
                boneDestroyed[rI][rJ]= true;
                boneRemodeled[rI][rJ]= true;
                int[] p1=convertCoordinates(rI,rJ-1);
                
                if ((age[rI][rJ]>=pOCdeath) || (rJ==1) ) { //used in normal case
                //if ((age[rI][rJ]>=resorption) || (rJ==1) ) { //used for intital zometa Therapy
                
                //if((timestep>30000) || (rJ==1)) { //used for timed zometa
                    // System.out.println ("age of death"+age[rI][rJ]);
                    Cells[rI][rJ]=0;
                    age[rI][rJ]=0;
                }
                
                else if (Timer[rI][rJ]>resorption){
                    //Reset Timer
                    
                    //System.out.println ("OB timer is "+Timer[rI][rJ]);
                    //Chew Bone!
                    Cells[p1[0]][p1[1]]=4;
                    age[p1[0]][p1[1]]=age[rI][rJ];
                    Timer[p1[0]][p1[1]]=0;
                    //Reset old place
                    Cells[rI][rJ]=0;
                    age[rI][rJ]=0;
                    Timer[rI][rJ]=0;
                }  
            }
            
            
//Mesenchymal Stem Cell
            //check if there are enough pOB
		    if ((cell==5) && (age[rI][rJ] % pOBborn==0)) {
		    	// If cells is a MSC create pOBs (Green)
		    	int[] p = findEmptySite (rI,rJ);
		    	if ((p[0]!=rI) || (p[1]!=rJ)) {
		    		Cells[p[0]][p[1]]=1;
		    		age[p[0]][p[1]]=0;
		    	}
		    }
			
            
//Tumour Receptor Producer Cell
            if (cell==6) {

                int divRate=0;
                tumourTGFB[rI][rJ]= true;
                
                //Mesenchymal Stem Cell Recruitment proportional to size
                if(random.nextInt(mscRec+1)>=mscRec){
                 
                 int[] p = findEmptySite (rI,rJ);
                 Cells[p[0]][p[1]]=5;
                 age[p[0]][p[1]]=pOBborn-1;
                 
                    //int l=random.nextInt(sizeX-1);
                    //int m=random.nextInt(sizeY-1-boneLimit);
                   // Cells[l][boneLimit+m]=5;
                   // age[l][boneLimit+m]=pOBborn-1;
                }
                
                if (boneRemodeling[rI][rJ]>=0.0001 /*|| TGFB[rI][rJ]>=highTGFB*/) {
                    divRate=7*day1;
                    }
                else if (boneRemodeling[rI][rJ]>=0.001 /*|| TGFB[rI][rJ]>=highTGFB*/) {
                    divRate=5*day1;
                    age[rI][rJ]=0;}
                else if (boneRemodeling[rI][rJ]>=0.01 /*|| TGFB[rI][rJ]>=highTGFB*/) {
                    divRate=3*day1;
                    age[rI][rJ]=0;}
                else if (boneRemodeling[rI][rJ]>=0.1 /*|| TGFB[rI][rJ]>=highTGFB*/) {
                    divRate=1*day1;
                    age[rI][rJ]=0;}
                                        
                else divRate=10*day1;
                
                // If not in contact with Bone Remodelling field for 2 weeks, die
                if (age[rI][rJ]>=day14 /*&& TGFB[rI][rJ]<lowTGFB*/) {
                    Cells[rI][rJ]=0;
                    age[rI][rJ]=0;
                    Timer[rI][rJ]=0;
                }
                
                //If alive and TGFB present, try to divide (once every day; 1 day= 240 ts)
                 else if (random.nextInt(divRate+1)>=divRate) {
                     //Mesenchymal Stem Cell Recruitment proportional to division summons an MSC->pOB every 10th division, to an adjacent space.
                     /*if (random.nextInt(5)>=4)
                     {int[] p = findEmptySite (rI,rJ);
                         if (Cells[p[0]][p[1]]==0) {
                             Cells[p[0]][p[1]]=5;
                             age[p[0]][p[1]]=pOBborn-1;}}
                     
                     else {*/
                    int[] p = findEmptySite (rI,rJ);
                    if (Cells[p[0]][p[1]]==0) {
                        Cells[p[0]][p[1]]=6;
                        age[p[0]][p[1]]=age[rI][rJ];}
                
                   // }
                }
                                
                     else if (Timer[rI][rJ]>=timerOB) {
                         //Reset Timer
                         Timer[rI][rJ]=0;
                         //Find Bone Remodeling Field, move ot it
                         int[] p = seekBoneRemodelingExt (rI,rJ);
                         
                         if ((p[0]!=rI) || (p[1]!=rJ)) {
                             Cells[p[0]][p[1]]=6;
                             age[p[0]][p[1]]=0;
                            // activeByTGFB[p[0]][p[1]]=true;
                             Cells[rI][rJ]=0;
                             age[rI][rJ]=0;
                           //  activeByTGFB[rI][rJ]=false;
                         }
                         
                         else {
                             // Move!
                             int[] q = findEmptySite (rI,rJ);
                             if ((q[0]!=rI) || (q[1]!=rJ)) {
                                 Cells[q[0]][q[1]]=6;
                                 Cells[rI][rJ]=0;
                                 age[q[0]][q[1]]=age[rI][rJ];
                                 age[rI][rJ]=0;
                               //  activeByTGFB[q[0]][q[1]]=activeByTGFB[rI][rJ];
                               //  activeByTGFB[rI][rJ]=false;
                             }
                             else {
                                 int[] q2 = findCanopySite (rI,rJ);
                                 if ((q2[0]!=rI) || (q2[1]!=rJ)) {
                                     Cells[q2[0]][q2[1]]=6;
                                     Cells[rI][rJ]=0;
                                     age[q2[0]][q2[1]]=age[rI][rJ];
                                     age[rI][rJ]=0;
                                   //  activeByTGFB[q2[0]][q2[1]]=activeByTGFB[rI][rJ];
                                    // activeByTGFB[rI][rJ]=false;
                                 }
                             }
                         }
                     }
			}
            
            
//Tumour Receptor Cell            
            if (cell==7) {
                
                int divRateTR=0;
                
                if (boneRemodeling[rI][rJ]>=0.01) {divRateTR=2*day1;}
                else {divRateTR=10*day1;}
                
                //If alive and TGFB present, try to divide (once every day; 1 day= 240 ts)
                if (random.nextInt(divRateTR+1)>=divRateTR) {
                    int[] p = findEmptySite (rI,rJ);
                    if ((p[0]!=rI) || (p[1]!=rJ)) {
                        Cells[p[0]][p[1]]=7;
                        age[p[0]][p[1]]=age[rI][rJ];
                    }
                }
                
                else if (Timer[rI][rJ]>=timerOB) {
                    //Reset Timer
                    Timer[rI][rJ]=0;
                    //Find TGFB, move ot it
                    int[] p = seekTGFB (rI,rJ);
                    
                    if ((p[0]!=rI) || (p[1]!=rJ)) {
                        Cells[p[0]][p[1]]=7;
                        age[p[0]][p[1]]=age[rI][rJ];
                       // activeByTGFB[p[0]][p[1]]=true;
                        Cells[rI][rJ]=0;
                        age[rI][rJ]=0;
                       // activeByTGFB[rI][rJ]=false;
                    }
                    
                    else {
                        // Move!
                        int[] q = findEmptySite (rI,rJ);
                        if ((q[0]!=rI) || (q[1]!=rJ)) {
                            Cells[q[0]][q[1]]=7;
                            Cells[rI][rJ]=0;
                            age[q[0]][q[1]]=age[rI][rJ];
                            age[rI][rJ]=0;
                          //  activeByTGFB[q[0]][q[1]]=activeByTGFB[rI][rJ];
                          //  activeByTGFB[rI][rJ]=false;
                        }
                        else {
                            int[] q2 = findCanopySite (rI,rJ);
                            if ((q2[0]!=rI) || (q2[1]!=rJ)) {
                                Cells[q2[0]][q2[1]]=7;
                                Cells[rI][rJ]=0;
                                age[q2[0]][q2[1]]=age[rI][rJ];
                                age[rI][rJ]=0;
                               // activeByTGFB[q2[0]][q2[1]]=activeByTGFB[rI][rJ];
                               // activeByTGFB[rI][rJ]=false;
                            }}
                    }
                }
			}
            
//Tumour Neutral Cell
            if (cell==8) {                
                //If alive and TGFB present, try to divide (once every 2 days; 1 day= 240 ts)
                if (random.nextInt(tnDiv+1)>=tnDiv) {
                    int[] p = findEmptySite (rI,rJ);
                    if ((p[0]!=rI) || (p[1]!=rJ)) {
                        Cells[p[0]][p[1]]=8;
                        age[p[0]][p[1]]=age[rI][rJ];
                    }
                }
                
                else if (Timer[rI][rJ]>=timerOB) {
                    //Reset Timer
                    Timer[rI][rJ]=0;
                    //Find TGFB, move ot it
                    
                        // Move!
                        int[] q = findEmptySite (rI,rJ);
                        if ((q[0]!=rI) || (q[1]!=rJ)) {
                            Cells[q[0]][q[1]]=8;
                            Cells[rI][rJ]=0;
                            age[q[0]][q[1]]=age[rI][rJ];
                            age[rI][rJ]=0;
                           // activeByTGFB[q[0]][q[1]]=activeByTGFB[rI][rJ];
                           // activeByTGFB[rI][rJ]=false;
                    }
                        else {
                            int[] q2 = findCanopySite (rI,rJ);
                            if ((q2[0]!=rI) || (q2[1]!=rJ)) {
                                Cells[q2[0]][q2[1]]=8;
                                Cells[rI][rJ]=0;
                                age[q2[0]][q2[1]]=age[rI][rJ];
                                age[rI][rJ]=0;
                              //  activeByTGFB[q2[0]][q2[1]]=activeByTGFB[rI][rJ];
                              //  activeByTGFB[rI][rJ]=false;
                            }}
			}
	  	}
        }
        
    
 	return true;
 }
	
final int vacantSites (int x, int y)
{
	int total=0;
	int[] p = new int [2];
		
	p=convertCoordinates (x+1,y-1);
	if (Cells[p[0]][p[1]]==0) total++;
	p=convertCoordinates (x+1,y);
	if (Cells[p[0]][p[1]]==0) total++;
	p=convertCoordinates (x+1,y+1);
	if (Cells[p[0]][p[1]]==0) total++;
	p=convertCoordinates (x,y-1);
	if (Cells[p[0]][p[1]]==0) total++;
	p=convertCoordinates (x,y+1);
	if (Cells[p[0]][p[1]]==0) total++;
	p=convertCoordinates (x-1,y-1);
	if (Cells[p[0]][p[1]]==0) total++;
	p=convertCoordinates (x-1,y);
	if (Cells[p[0]][p[1]]==0) total++;
	p=convertCoordinates (x-1,y+1);
	if (Cells[p[0]][p[1]]==0) total++;
	return total;
}
	

int[] findEmptySite (int x, int y)
{
	LinkedList vacantSites = new LinkedList();
	int[] tp1 = new int[2];
	int[] tp2 = new int[2];
	int[] tp3 = new int[2];
	int[] tp4 = new int[2];
	int[] tp5 = new int[2];
	int[] tp6 = new int[2];
	int[] tp7 = new int[2];
	int[] tp8 = new int[2];
	
	tp1=convertCoordinates (x+1,y-1);
	if (Cells[tp1[0]][tp1[1]]==0) vacantSites.add(tp1);
	tp2=convertCoordinates (x+1,y);
	if (Cells[tp2[0]][tp2[1]]==0) vacantSites.add(tp2);
	tp3=convertCoordinates (x+1,y+1);
	if (Cells[tp3[0]][tp3[1]]==0) vacantSites.add(tp3);
	tp4=convertCoordinates (x,y-1);
	if (Cells[tp4[0]][tp4[1]]==0) vacantSites.add(tp4);
	tp5=convertCoordinates (x,y+1);
	if (Cells[tp5[0]][tp5[1]]==0) vacantSites.add(tp5);
	tp6=convertCoordinates (x-1,y-1);
	if (Cells[tp6[0]][tp6[1]]==0) vacantSites.add(tp6);
	tp7=convertCoordinates (x-1,y);
	if (Cells[tp7[0]][tp7[1]]==0) vacantSites.add(tp7);
	tp8=convertCoordinates (x-1,y+1);
	if (Cells[tp8[0]][tp8[1]]==0) vacantSites.add(tp8);
	
	// Now let's see where.
	if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
		// pick a vacant site and return it
		int vacantElemIndex = random.nextInt(vacantSites.size());
		int[] p = (int[])vacantSites.get(vacantElemIndex);
		return (int[])p;	
	} else {
		int[] p = new int[2];
		p[0] = x; p[1] = y; // Just return the original
		//System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
		return p;
	}

}
    
    
    int[] findCanopySite (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp8 = new int[2];
        
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp2[0]][tp2[1]]==10) vacantSites.add(tp2);
        tp3=convertCoordinates (x+1,y+1);
        if (Cells[tp3[0]][tp3[1]]==10) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp4[0]][tp4[1]]==10) vacantSites.add(tp4);
        tp5=convertCoordinates (x,y+1);
        if (Cells[tp5[0]][tp5[1]]==10) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp6[0]][tp6[1]]==10) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==10) vacantSites.add(tp7);
        tp8=convertCoordinates (x-1,y+1);
        if (Cells[tp8[0]][tp8[1]]==10) vacantSites.add(tp8);
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;	
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    int[] seekBoneRemodeling (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp8 = new int[2];
        
        tp1=convertCoordinates (x+1,y-1);
        if ((boneRemodeling[tp1[0]][tp1[1]]>boneRemodeling[x][y]) && Cells[tp1[0]][tp1[1]]==0) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if ((boneRemodeling[tp2[0]][tp2[1]]>boneRemodeling[x][y]) && Cells[tp2[0]][tp2[1]]==0) vacantSites.add(tp2);
        tp3=convertCoordinates (x+1,y+1);
        if ((boneRemodeling[tp3[0]][tp3[1]]>boneRemodeling[x][y]) && Cells[tp3[0]][tp3[1]]==0) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if ((boneRemodeling[tp4[0]][tp4[1]]>boneRemodeling[x][y]) && Cells[tp4[0]][tp4[1]]==0) vacantSites.add(tp4);
        tp5=convertCoordinates (x,y+1);
        if ((boneRemodeling[tp5[0]][tp5[1]]>boneRemodeling[x][y]) && Cells[tp5[0]][tp5[1]]==0) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if ((boneRemodeling[tp6[0]][tp6[1]]>boneRemodeling[x][y]) && Cells[tp6[0]][tp6[1]]==0) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if ((boneRemodeling[tp7[0]][tp7[1]]>boneRemodeling[x][y]) && Cells[tp7[0]][tp7[1]]==0) vacantSites.add(tp7);
        tp8=convertCoordinates (x-1,y+1);
        if ((boneRemodeling[tp8[0]][tp8[1]]>boneRemodeling[x][y]) && Cells[tp8[0]][tp8[1]]==0) vacantSites.add(tp8);
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    
    int[] seekBoneRemodelingExt (int x, int y)
    {
        LinkedList tgfbSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp1a = new int[2];
        int[] tp1b = new int[2];
        int[] tp2 = new int[2];
        int[] tp2a = new int[2];
        int[] tp2b = new int[2];
        int[] tp3 = new int[2];
        int[] tp3a = new int[2];
        int[] tp3b = new int[2];
        int[] tp4 = new int[2];
        int[] tp4a = new int[2];
        int[] tp4b = new int[2];
        int[] tp5 = new int[2];
        int[] tp5a = new int[2];
        int[] tp5b = new int[2];
        int[] tp6 = new int[2];
        int[] tp6a = new int[2];
        int[] tp6b = new int[2];
        int[] tp7 = new int[2];
        int[] tp7a = new int[2];
        int[] tp7b = new int[2];
        int[] tp8 = new int[2];
        int[] tp8a = new int[2];
        int[] tp8b = new int[2];
        
        //Sense if there is enough space to move
        tp1=convertCoordinates (x+1,y-1);
        tp1a=convertCoordinates (x+2,y-2);
        tp1b=convertCoordinates (x+3,y-3);
        
        if (boneRemodeling[tp1[0]][tp1[1]]>boneRemodeling[x][y] && Cells[tp1[0]][tp1[1]]==0 && Cells[tp1a[0]][tp1a[1]]==0) tgfbSites.add(tp1);
        
        tp2=convertCoordinates (x+1,y);
        tp2a=convertCoordinates (x+2,y);
        tp2b=convertCoordinates (x+3,y);
        
        if (boneRemodeling[tp2[0]][tp2[1]]>boneRemodeling[x][y] && Cells[tp2[0]][tp2[1]]==0 && Cells[tp2a[0]][tp2a[1]]==0) tgfbSites.add(tp2);
        
        tp3=convertCoordinates (x+1,y+1);
        tp3a=convertCoordinates (x+2,y+2);
        tp3b=convertCoordinates (x+3,y+3);
        
        if (boneRemodeling[tp3[0]][tp3[1]]>boneRemodeling[x][y] && Cells[tp3[0]][tp3[1]]==0 && Cells[tp3a[0]][tp3a[1]]==0) tgfbSites.add(tp3);
        
        tp4=convertCoordinates (x,y-1);
        tp4a=convertCoordinates (x,y-2);
        tp4b=convertCoordinates (x,y-3);
        
        if (boneRemodeling[tp4[0]][tp4[1]]>boneRemodeling[x][y] && Cells[tp4[0]][tp4[1]]==0 && Cells[tp4a[0]][tp4a[1]]==0) tgfbSites.add(tp4);
        
        tp5=convertCoordinates (x,y+1);
        tp5a=convertCoordinates (x,y+2);
        tp5b=convertCoordinates (x,y+3);
        if (boneRemodeling[tp5[0]][tp5[1]]>boneRemodeling[x][y] && Cells[tp5[0]][tp5[1]]==0 && Cells[tp5a[0]][tp5a[1]]==0) tgfbSites.add(tp5);
        
        tp6=convertCoordinates (x-1,y-1);
        tp6a=convertCoordinates (x-2,y-2);
        tp6b=convertCoordinates (x-3,y-3);
        if (boneRemodeling[tp6[0]][tp6[1]]>boneRemodeling[x][y] && Cells[tp6[0]][tp6[1]]==0 && Cells[tp6a[0]][tp6a[1]]==0) tgfbSites.add(tp6);
        
        tp7=convertCoordinates (x-1,y);
        tp7a=convertCoordinates (x-2,y);
        tp7b=convertCoordinates (x-3,y);
        if (boneRemodeling[tp7[0]][tp7[1]]>boneRemodeling[x][y] && Cells[tp7[0]][tp7[1]]==0 && Cells[tp7a[0]][tp7a[1]]==0) tgfbSites.add(tp7);
        
        tp8=convertCoordinates (x-1,y+1);
        tp8a=convertCoordinates (x-2,y+2);
        tp8b=convertCoordinates (x-3,y+3);
        if (boneRemodeling[tp8[0]][tp8[1]]>boneRemodeling[x][y] && Cells[tp8[0]][tp8[1]]==0 && Cells[tp8a[0]][tp8a[1]]==0) tgfbSites.add(tp8);
        
        
        // Now let's see where.
        if (tgfbSites.size() > 0) { // Now choose a tgfb site one, otherwise return the original location
            // pick a tgfb site and return it
            int tgfbElemIndex = random.nextInt(tgfbSites.size());
            int[] p = (int[])tgfbSites.get(tgfbElemIndex);
            return (int[])p;
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    
    int[] seekRANKL (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        //int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        //int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        //int[] tp8 = new int[2];
        
        tp1=convertCoordinates (x+1,y-1);
        if ((RANKL[tp1[0]][tp1[1]]>RANKL[x][y]) && Cells[tp1[0]][tp1[1]]==0) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if ((RANKL[tp2[0]][tp2[1]]>RANKL[x][y]) && Cells[tp2[0]][tp2[1]]==0) vacantSites.add(tp2);
        //tp3=convertCoordinates (x+1,y+1);
        //if ((RANKL[tp3[0]][tp3[1]]>RANKL[x][y]) && Cells[tp3[0]][tp3[1]]==0) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if ((RANKL[tp4[0]][tp4[1]]>RANKL[x][y]) && Cells[tp4[0]][tp4[1]]==0) vacantSites.add(tp4);
        //tp5=convertCoordinates (x,y+1);
        //if ((RANKL[tp5[0]][tp5[1]]>RANKL[x][y]) && Cells[tp5[0]][tp5[1]]==0) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if ((RANKL[tp6[0]][tp6[1]]>RANKL[x][y]) && Cells[tp6[0]][tp6[1]]==0) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if ((RANKL[tp7[0]][tp7[1]]>RANKL[x][y]) && Cells[tp7[0]][tp7[1]]==0) vacantSites.add(tp7);
        //tp8=convertCoordinates (x-1,y+1);
        //if ((RANKL[tp8[0]][tp8[1]]>RANKL[x][y]) && Cells[tp8[0]][tp8[1]]==0) vacantSites.add(tp8);
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    int[] seekTGFB (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp8 = new int[2];
        
        tp1=convertCoordinates (x+1,y-1);
        if ((TGFB[tp1[0]][tp1[1]]>TGFB[x][y]) && Cells[tp1[0]][tp1[1]]==0) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if ((TGFB[tp2[0]][tp2[1]]>TGFB[x][y]) && Cells[tp2[0]][tp2[1]]==0) vacantSites.add(tp2);
        tp3=convertCoordinates (x+1,y+1);
        if ((TGFB[tp3[0]][tp3[1]]>TGFB[x][y]) && Cells[tp3[0]][tp3[1]]==0) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if ((TGFB[tp4[0]][tp4[1]]>TGFB[x][y]) && Cells[tp4[0]][tp4[1]]==0) vacantSites.add(tp4);
        tp5=convertCoordinates (x,y+1);
        if ((TGFB[tp5[0]][tp5[1]]>TGFB[x][y]) && Cells[tp5[0]][tp5[1]]==0) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if ((TGFB[tp6[0]][tp6[1]]>TGFB[x][y]) && Cells[tp6[0]][tp6[1]]==0) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if ((TGFB[tp7[0]][tp7[1]]>TGFB[x][y]) && Cells[tp7[0]][tp7[1]]==0) vacantSites.add(tp7);
        tp8=convertCoordinates (x-1,y+1);
        if ((TGFB[tp8[0]][tp8[1]]>TGFB[x][y]) && Cells[tp8[0]][tp8[1]]==0) vacantSites.add(tp8);
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    
    int[] seekTGFBext (int x, int y)
    {
        LinkedList tgfbSites = new LinkedList();
        //int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp2a = new int[2];
        int[] tp2b = new int[2];
        int[] tp3 = new int[2];
        int[] tp3a = new int[2];
        int[] tp3b = new int[2];
        //int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp5a = new int[2];
        int[] tp5b = new int[2];
        //int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp7a = new int[2];
        int[] tp7b = new int[2];
        int[] tp8 = new int[2];
        int[] tp8a = new int[2];
        int[] tp8b = new int[2];
        
        /*
         tp1=convertCoordinates (x+1,y-1);
         tp1a=convertCoordinates (x+2,y-2);
         tp1b=convertCoordinates (x+3,y-3);
         
         if (TGFB[tp1[0]][tp1[1]]>TGFB[x][y] && Cells[tp1[0]][tp1[1]]==0) tgfbSites.add(tp1);
         if (TGFB[tp1a[0]][tp1a[1]]>TGFB[x][y] && Cells[tp1[0]][tp1[1]]==0) tgfbSites.add(tp1);
         if (TGFB[tp1b[0]][tp1b[1]]>TGFB[x][y] && Cells[tp1[0]][tp1[1]]==0) tgfbSites.add(tp1);
         */
        
        
        //Sense TGFB up to three spaces up
        tp2=convertCoordinates (x+1,y);
        tp2a=convertCoordinates (x+2,y);
        tp2b=convertCoordinates (x+3,y);
        
        if (TGFB[tp2[0]][tp2[1]]>TGFB[x][y] && Cells[tp2[0]][tp2[1]]==0) tgfbSites.add(tp2);
        if (TGFB[tp2a[0]][tp2a[1]]>TGFB[x][y] && Cells[tp2[0]][tp2[1]]==0) tgfbSites.add(tp2);
        if (TGFB[tp2b[0]][tp2b[1]]>TGFB[x][y] && Cells[tp2[0]][tp2[1]]==0) tgfbSites.add(tp2);
        
        tp3=convertCoordinates (x+1,y+1);
        tp3a=convertCoordinates (x+2,y+2);
        tp3b=convertCoordinates (x+3,y+3);
        
        if (TGFB[tp3[0]][tp3[1]]>TGFB[x][y] && Cells[tp3[0]][tp3[1]]==0) tgfbSites.add(tp3);
        if (TGFB[tp3a[0]][tp3a[1]]>TGFB[x][y] && Cells[tp3[0]][tp3[1]]==0) tgfbSites.add(tp3);        
        if (TGFB[tp3b[0]][tp3b[1]]>TGFB[x][y] && Cells[tp3[0]][tp3[1]]==0) tgfbSites.add(tp3);
        
        /*
         tp4=convertCoordinates (x,y-1);
         tp4a=convertCoordinates (x,y-2);
         tp4b=convertCoordinates (x,y-3);         
         if (TGFB[tp4[0]][tp4[1]]>TGFB[x][y] && Cells[tp4[0]][tp4[1]]==0) tgfbSites.add(tp4);
         if (TGFB[tp4a[0]][tp4a[1]]>TGFB[x][y] && Cells[tp4[0]][tp4[1]]==0) tgfbSites.add(tp4);
         if (TGFB[tp4b[0]][tp4b[1]]>TGFB[x][y] && Cells[tp4[0]][tp4[1]]==0) tgfbSites.add(tp4);
         */
        
        
        tp5=convertCoordinates (x,y+1);
        tp5a=convertCoordinates (x,y+2);
        tp5b=convertCoordinates (x,y+3);
        if (TGFB[tp5[0]][tp5[1]]>TGFB[x][y] && Cells[tp5[0]][tp5[1]]==0) tgfbSites.add(tp5);
        if (TGFB[tp5a[0]][tp5a[1]]>TGFB[x][y] && Cells[tp5[0]][tp5[1]]==0) tgfbSites.add(tp5);
        if (TGFB[tp5b[0]][tp5b[1]]>TGFB[x][y] && Cells[tp5[0]][tp5[1]]==0) tgfbSites.add(tp5);
        
        /*         
         tp6=convertCoordinates (x-1,y-1);
         tp6a=convertCoordinates (x-2,y-2);
         tp6b=convertCoordinates (x-3,y-3);
         if (TGFB[tp6[0]][tp6[1]]>TGFB[x][y] && Cells[tp6[0]][tp6[1]]==0) tgfbSites.add(tp6);
         if (TGFB[tp6a[0]][tp6a[1]]>TGFB[x][y] && Cells[tp6[0]][tp6[1]]==0) tgfbSites.add(tp6);
         if (TGFB[tp6b[0]][tp6b[1]]>TGFB[x][y] && Cells[tp6[0]][tp6[1]]==0) tgfbSites.add(tp6);
         */
        
        tp7=convertCoordinates (x-1,y);
        tp7a=convertCoordinates (x-2,y);
        tp7b=convertCoordinates (x-3,y);
        if (TGFB[tp7[0]][tp7[1]]>TGFB[x][y] && Cells[tp7[0]][tp7[1]]==0) tgfbSites.add(tp7);
        if (TGFB[tp7a[0]][tp7a[1]]>TGFB[x][y] && Cells[tp7[0]][tp7[1]]==0) tgfbSites.add(tp7);
        if (TGFB[tp7b[0]][tp7b[1]]>TGFB[x][y] && Cells[tp7[0]][tp7[1]]==0) tgfbSites.add(tp7);
        
        
        tp8=convertCoordinates (x-1,y+1);
        tp8a=convertCoordinates (x-2,y+2);
        tp8b=convertCoordinates (x-3,y+3);
        if (TGFB[tp8[0]][tp8[1]]>TGFB[x][y] && Cells[tp8[0]][tp8[1]]==0) tgfbSites.add(tp8);
        if (TGFB[tp8a[0]][tp8a[1]]>TGFB[x][y] && Cells[tp8[0]][tp8[1]]==0) tgfbSites.add(tp8);
        if (TGFB[tp8b[0]][tp8b[1]]>TGFB[x][y] && Cells[tp8[0]][tp8[1]]==0) tgfbSites.add(tp8);
        
        
        // Now let's see where.
        if (tgfbSites.size() > 0) { // Now choose a tgfb site one, otherwise return the original location
            // pick a tgfb site and return it
            int tgfbElemIndex = random.nextInt(tgfbSites.size());
            int[] p = (int[])tgfbSites.get(tgfbElemIndex);
            return (int[])p;
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    //Finds an empty spot downwards (trough canopy too!)
    int[] findEmptySiteDownwards2 (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp8 = new int[2];
        
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==6 || Cells[tp1[0]][tp1[1]]==7 || Cells[tp1[0]][tp1[1]]==8 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==6 || Cells[tp1[0]][tp1[1]]==7 || Cells[tp1[0]][tp1[1]]==8 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp2);
        //tp3=convertCoordinates (x+1,y+1);
        //if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==6 || Cells[tp1[0]][tp1[1]]==7 || Cells[tp1[0]][tp1[1]]==8 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==6 || Cells[tp1[0]][tp1[1]]==7 || Cells[tp1[0]][tp1[1]]==8 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp4);
        //tp5=convertCoordinates (x,y+1);
        //if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==6 || Cells[tp1[0]][tp1[1]]==7 || Cells[tp1[0]][tp1[1]]==8 || Cells[tp1[0]][tp1[1]]==10);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==6 || Cells[tp1[0]][tp1[1]]==7 || Cells[tp1[0]][tp1[1]]==8 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp7);
        //tp8=convertCoordinates (x-1,y+1);
        //if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==6 || Cells[tp1[0]][tp1[1]]==7 || Cells[tp1[0]][tp1[1]]==8 || Cells[tp1[0]][tp1[1]]==10);
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    
    //Finds an empty spot downwards (trough canopy too!)
    int[] findEmptySiteDownwards (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp8 = new int[2];
        
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp2[0]][tp2[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp2);
        //tp3=convertCoordinates (x+1,y+1);
        //if (Cells[tp3[0]][tp3[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp4[0]][tp4[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp4);
        //tp5=convertCoordinates (x,y+1);
        //if (Cells[tp5[0]][tp5[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp6[0]][tp6[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp7);
        //tp8=convertCoordinates (x-1,y+1);
        //if (Cells[tp8[0]][tp8[1]]==0 || Cells[tp1[0]][tp1[1]]==10) vacantSites.add(tp8);
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;	
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }


    //Finds bone downwards (better for Osteoclasts!)
    int[] seekBone (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp8 = new int[2];
        
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==9) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp2[0]][tp2[1]]==9) vacantSites.add(tp2);
        //tp3=convertCoordinates (x+1,y+1);
        //if (Cells[tp3[0]][tp3[1]]==9) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp4[0]][tp4[1]]==9) vacantSites.add(tp4);
        //tp5=convertCoordinates (x,y+1);
        //if (Cells[tp5[0]][tp5[1]]==9) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp6[0]][tp6[1]]==9) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==9) vacantSites.add(tp7);
        //tp8=convertCoordinates (x-1,y+1);
        //if (Cells[tp8[0]][tp8[1]]==9) vacantSites.add(tp8);
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    
    //Method for Osteoclasts
int[] findBoneDestroy (int x, int y)
{
	LinkedList boneSites = new LinkedList();

	int[] tp1 = new int[2];
	int[] tp4 = new int[2];
	int[] tp5 = new int[2];
	int[] tp7 = new int[2];
	int[] tp8 = new int[2];

	//tp1=convertCoordinates (x-1,y);
	//tp4=convertCoordinates (x+1,y);
	if(y==sizeY) {
	tp5[0]=x;
	tp5[1]=y;}
	else tp5=convertCoordinates (x,y+1);
	//tp7=convertCoordinates (x,y-1);
	tp8=convertCoordinates(x,y);
    
    
	//if ((Cells[tp1[0]][tp1[1]]==9) && (age[tp1[0]][tp1[1]]>3)) return tp1;
	//else if ((Cells[tp4[0]][tp4[1]]==9) && (age[tp1[0]][tp1[1]]>3)) return tp4; //boneSites.add(tp4);
	//else
    if ((Cells[tp5[0]][tp5[1]]==9) && (age[tp5[0]][tp5[1]]>3)) return tp5; //boneSites.add(tp5);
	//else if ((Cells[tp7[0]][tp7[1]]==9) && (age[tp7[0]][tp7[1]]>3)) return tp7; //boneSites.add(tp7);
	else {return tp8;}


}

int[] findBoneCreate (int x, int y)
{
	LinkedList vacantSites = new LinkedList();
    /*int[] tp1 = new int[2];
    int[] tp2 = new int[2];*/
    int[] tp3 = new int[2];
    /*int[] tp4 = new int[2];
    int[] tp5 = new int[2];
    int[] tp6 = new int[2];
    int[] tp7 = new int[2];
    int[] tp8 = new int[2];*/
    
    
    //No Homeostasis
    
    /*tp1=convertCoordinates (x+1,y-1);
    if (Cells[tp1[0]][tp1[1]]==0) vacantSites.add(tp1);
    tp2=convertCoordinates (x+1,y);
    if (Cells[tp2[0]][tp2[1]]==0 ) vacantSites.add(tp2);*/
    
    tp3=convertCoordinates (x+1,y+1);
    if (Cells[tp3[0]][tp3[1]]==0 ) vacantSites.add(tp3);    
    
    /*tp4=convertCoordinates (x,y-1);
    if (Cells[tp4[0]][tp4[1]]==0 ) vacantSites.add(tp4);
    tp5=convertCoordinates (x,y+1);
    if (Cells[tp5[0]][tp5[1]]==0 ) vacantSites.add(tp5);
    tp6=convertCoordinates (x-1,y-1);
    if (Cells[tp6[0]][tp6[1]]==0 ) vacantSites.add(tp6);
    tp7=convertCoordinates (x-1,y);
    if (Cells[tp7[0]][tp7[1]]==0 ) vacantSites.add(tp7);
    tp8=convertCoordinates (x-1,y+1);
    if (Cells[tp8[0]][tp8[1]]==0 ) vacantSites.add(tp8);*/
    
    
    
    
    // Now let's see where.
    if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
        // pick a vacant site and return it
        int vacantElemIndex = random.nextInt(vacantSites.size());
        int[] p = (int[])vacantSites.get(vacantElemIndex);
        return (int[])p;
    } else {
        int[] p = new int[2];
        p[0] = x; p[1] = y; // Just return the original
        //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
        return p;
    }

}

    
    int[] findBoneCreateAlt (int x, int y)
    {
        LinkedList vacantSites = new LinkedList();
        int[] tp1 = new int[2];
        int[] tp2 = new int[2];
        int[] tp3 = new int[2];
        int[] tp4 = new int[2];
        int[] tp5 = new int[2];
        int[] tp6 = new int[2];
        int[] tp7 = new int[2];
        int[] tp8 = new int[2];
        
      
  //No Homeostasis
        
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==0) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp2[0]][tp2[1]]==0 ) vacantSites.add(tp2);
        tp3=convertCoordinates (x+1,y+1);
        if (Cells[tp3[0]][tp3[1]]==0 ) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp4[0]][tp4[1]]==0 ) vacantSites.add(tp4);
        tp5=convertCoordinates (x,y+1);
        if (Cells[tp5[0]][tp5[1]]==0 ) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp6[0]][tp6[1]]==0 ) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==0 ) vacantSites.add(tp7);
        tp8=convertCoordinates (x-1,y+1);
        if (Cells[tp8[0]][tp8[1]]==0 ) vacantSites.add(tp8);

          
   /*Artificial Homeostasis at boneLimit
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==0 && y<boneLimit) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp2[0]][tp2[1]]==0 && y<boneLimit) vacantSites.add(tp2);
        tp3=convertCoordinates (x+1,y+1);
        if (Cells[tp3[0]][tp3[1]]==0 && y<boneLimit) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp4[0]][tp4[1]]==0 && y<boneLimit) vacantSites.add(tp4);
        tp5=convertCoordinates (x,y+1);
        if (Cells[tp5[0]][tp5[1]]==0 && y<boneLimit) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp6[0]][tp6[1]]==0 && y<boneLimit) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==0 && y<boneLimit) vacantSites.add(tp7);
        tp8=convertCoordinates (x-1,y+1);
        if (Cells[tp8[0]][tp8[1]]==0 && y<boneLimit) vacantSites.add(tp8);
       */ 
        
     /*   //Artificial Homeostasis at boneLimit+20
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==0 && y<boneLimit-20) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp2[0]][tp2[1]]==0 && y<boneLimit-20) vacantSites.add(tp2);
        tp3=convertCoordinates (x+1,y+1);
        if (Cells[tp3[0]][tp3[1]]==0 && y<boneLimit-20) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp4[0]][tp4[1]]==0 && y<boneLimit-20) vacantSites.add(tp4);
        tp5=convertCoordinates (x,y+1);
        if (Cells[tp5[0]][tp5[1]]==0 && y<boneLimit-20) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp6[0]][tp6[1]]==0 && y<boneLimit-20) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==0 && y<boneLimit-20) vacantSites.add(tp7);
        tp8=convertCoordinates (x-1,y+1);
        if (Cells[tp8[0]][tp8[1]]==0 && y<boneLimit-20) vacantSites.add(tp8);
        
/*
  //Artificial Homeostasis at line 20      
        tp1=convertCoordinates (x+1,y-1);
        if (Cells[tp1[0]][tp1[1]]==0 && y<20) vacantSites.add(tp1);
        tp2=convertCoordinates (x+1,y);
        if (Cells[tp2[0]][tp2[1]]==0 && y<20) vacantSites.add(tp2);
        tp3=convertCoordinates (x+1,y+1);
        if (Cells[tp3[0]][tp3[1]]==0 && y<20) vacantSites.add(tp3);
        tp4=convertCoordinates (x,y-1);
        if (Cells[tp4[0]][tp4[1]]==0 && y<20) vacantSites.add(tp4);
        tp5=convertCoordinates (x,y+1);
        if (Cells[tp5[0]][tp5[1]]==0 && y<20) vacantSites.add(tp5);
        tp6=convertCoordinates (x-1,y-1);
        if (Cells[tp6[0]][tp6[1]]==0 && y<20) vacantSites.add(tp6);
        tp7=convertCoordinates (x-1,y);
        if (Cells[tp7[0]][tp7[1]]==0 && y<20) vacantSites.add(tp7);
        tp8=convertCoordinates (x-1,y+1);
        if (Cells[tp8[0]][tp8[1]]==0 && y<20) vacantSites.add(tp8);
 */
        
        // Now let's see where.
        if (vacantSites.size() > 0) { // Now choose a vacant one, otherwise return the original location
            // pick a vacant site and return it
            int vacantElemIndex = random.nextInt(vacantSites.size());
            int[] p = (int[])vacantSites.get(vacantElemIndex);
            return (int[])p;	
        } else {
            int[] p = new int[2];
            p[0] = x; p[1] = y; // Just return the original
            //System.out.println ("wrong!:"+vacantSites (x,y)+" - "+vacantSites.size());
            return p;
        }
        
    }
    
    
public void iterateTGFB()
	{
		float[][] newTGFB = new float[sizeX][sizeY];
		for (int rI = 0; rI < sizeX; rI++)
			for (int rJ = 0; rJ < sizeY; rJ++)
			{
				// Determine the actual coordinates for top (-1,0), left(0,-1), right(0,1), below(1,0)
				// using periodic boundary conditions
				int[] top = convertCoordinatesNoB(rI - 1, rJ);
				int[] left = convertCoordinatesNoB(rI, rJ - 1);//maybe change this?
				int[] right = convertCoordinatesNoB(rI, rJ + 1);//and this??
                int[] below = convertCoordinatesNoB(rI+1, rJ);

                    newTGFB[rI][rJ]
                    = TGFB[rI][rJ] + (kDt*
                                      (TGFB[top[0]][top[1]]
                                       + TGFB[left[0]][left[1]]
                                       + TGFB[right[0]][right[1]]
                                       + TGFB[below[0]][below[1]]
                                       - 4 * TGFB[rI][rJ]));
                    newTGFB[rI][rJ] = newTGFB[rI][rJ] * (1-tgfbDecayRate);                 
                
				if ((boneDestroyed[rI][rJ]) && ((TGFB[rI][rJ] < 1.0f))){
					newTGFB[rI][rJ]+=boneTGFBreleaseRate * (1-TGFB[rI][rJ]);
                    boneDestroyed[rI][rJ]=false;
				}
                
                else if ((tumourTGFB[rI][rJ]) && ((TGFB[rI][rJ] < 1.0f))){
                    //newTGFB[rI][rJ]=newTGFB[rI][rJ]/100;
					newTGFB[rI][rJ]+=cellTGFBreleaseRate * (1-TGFB[rI][rJ]);
                    tumourTGFB[rI][rJ]=false;                    
				}
			}
		TGFB = newTGFB;
	}
    
    
    
    public void iterateRemodeling()
	{
		float[][] newRemodeling = new float[sizeX][sizeY];
		for (int rI = 0; rI < sizeX; rI++)
			for (int rJ = 0; rJ < sizeY; rJ++)
			{
				// Determine the actual coordinates for top (-1,0), left(0,-1), right(0,1), below(1,0)
				// using periodic boundary conditions
				int[] top = convertCoordinatesNoB(rI - 1, rJ);
				int[] left = convertCoordinatesNoB(rI, rJ - 1);//maybe change this?
				int[] right = convertCoordinatesNoB(rI, rJ + 1);//and this??
                int[] below = convertCoordinatesNoB(rI+1, rJ);
                

                newRemodeling[rI][rJ]
                = boneRemodeling[rI][rJ] + (kDtremodeling*
                                  (boneRemodeling[top[0]][top[1]]
                                   + boneRemodeling[left[0]][left[1]]
                                   + boneRemodeling[right[0]][right[1]]
                                   + boneRemodeling[below[0]][below[1]]
                                   - 4 * boneRemodeling[rI][rJ]));
                newRemodeling[rI][rJ] = newRemodeling[rI][rJ] * (1-remodelingDecayRate);
         
				if ((boneRemodeled[rI][rJ]) && ((boneRemodeling[rI][rJ] < 1.0f))){
					newRemodeling[rI][rJ]+=remodelingreleaseRate * (1-boneRemodeling[rI][rJ]);
                    boneRemodeled[rI][rJ]=false;
				}
                

			}
		boneRemodeling = newRemodeling;
       // System.out.println ("remodeling happening!");
	}
    
    public void iterateRANKL()
	{
		float[][] newRANKL = new float[sizeX][sizeY];
		for (int rI = 0; rI < sizeX; rI++)
			for (int rJ = 0; rJ < sizeY; rJ++)
			{
				// Determine the actual coordinates for top (-1,0), left(0,-1), right(0,1), below(1,0)
				// using periodic boundary conditions
				int[] top = convertCoordinatesNoB(rI - 1, rJ);
				int[] left = convertCoordinatesNoB(rI, rJ - 1);//maybe change this?
				int[] right = convertCoordinatesNoB(rI, rJ + 1);//and this??
                int[] below = convertCoordinatesNoB(rI+1, rJ);
                
                newRANKL[rI][rJ]
                = RANKL[rI][rJ] + (RANKLkDt*
                                  (RANKL[top[0]][top[1]]
                                   + RANKL[left[0]][left[1]]
                                   + RANKL[right[0]][right[1]]
                                   + RANKL[below[0]][below[1]]
                                   - 4 * RANKL[rI][rJ]));
                newRANKL[rI][rJ] = newRANKL[rI][rJ] * (1-RANKLDecayRate);
                
				if ((pOBRANKL[rI][rJ]) && ((RANKL[rI][rJ] < 1.0f))){
					newRANKL[rI][rJ]+=RANKLreleaseRate * (1-RANKL[rI][rJ]);
                    pOBRANKL[rI][rJ]=false;
				}
                
			}
		RANKL = newRANKL;
	}
    
    public int[][] getCells() {return Cells;}
    public float [][] getTGFB() { return TGFB; }
    public float [][] getRANKL() { return RANKL; }
    public float [][] getRemodeling() { return boneRemodeling; }
    public int[][] getAge () {return age;}

};
