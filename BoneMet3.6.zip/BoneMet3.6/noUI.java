import java.util.*;
import java.io.*;

public class noUI extends Object {
	public static String version =" 3rd March 2010";
	public CA ca;
	int timestep=0;
	public int size=500;
	
	public static void  main (String args[])
	{
		System.err.println ("# noUI version: "+noUI.version);
		System.err.println ("# CA version: "+CA.version);
		
		int maxTS=1000;
		float SCSymmetricDivBalance=0.2f;
		int maxDivisions=10;
		int maxAge=10;
		float densityV=0.04f;
		if (args.length==5) {
			SCSymmetricDivBalance = Float.parseFloat (args[0]);
			maxDivisions = Integer.parseInt (args[1]);
			maxAge = Integer.parseInt (args[2]);
			maxTS=Integer.parseInt (args[3]);
			densityV = Float.parseFloat (args[4]);
			System.err.println ("Balance: "+SCSymmetricDivBalance+" maxDiv: "+maxDivisions+" maxAge: "+maxAge+ " maxTS: "+ maxTS);
		} else {
			System.err.println ("Arguments needed: s/a maxDivisions maxAge timesteps");
			System.exit(-1);
		}
		
		CA ca = new CA(SCSymmetricDivBalance, maxDivisions, maxAge,densityV);
		boolean finished = false;
		int ts=0;
		while (ts!=maxTS) {
			ca.nextTimeStep();
			ts++;
		}
	}
};