import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.imageio.*;
import java.awt.image.*;
import javax.swing.filechooser.*;
import java.util.*;
import java.io.*;
import java.lang.Math.*;//for rounding up age

public class Vis extends JApplet implements ActionListener{
	public static String version="8 May 2013";
	final static Color bg = Color.white;
	final static Color fg = Color.black;
	Dimension totalSize;
	public BufferedImage img; 
	public int sizeX=200;
	public int sizeY=150;
	int numParticles=0;
	int[][] OriginalMatrix;
	int mag=1; // Magnification factor (probably best use mag in CA.java)
	public CA ca;
	int counter=0; // Timesteps counter
	int defaultView=0; // Cells view
	JButton button;
	int timestep=0;
	boolean movie=true;
	public boolean play=true;
	JFileChooser fc;
	JLabel label;
	JCheckBox cb;
	String rootDir=".";
    //int seedVis=2;


	public Vis (JButton b, JLabel l, JCheckBox _cb)
	{
		fc = new JFileChooser();
		button = b;
		label = l;
		cb=_cb;
		ca = new CA();
		sizeX=ca.sizeX;
		sizeY=ca.sizeY;
		//mag = ca.mag;
        mag=2; //bizzarely, this is the actual parameter that determines magnification. Its super weird.
		img = new BufferedImage (ca.sizeX*ca.mag,ca.sizeY*ca.mag,BufferedImage.TYPE_INT_ARGB);
		
	}
	
	public final BufferedImage scale(double scale, BufferedImage srcImg) 
	{ 
		if (scale == 1)  return srcImg; 
   		AffineTransformOp op = new AffineTransformOp( AffineTransform.getScaleInstance( scale, scale), null); 
        	return op.filter(srcImg, null); 
	}

	public void paint(Graphics g) {
        	Graphics2D g2 = (Graphics2D) g;
			BufferedImage img2=scale (mag,img);
			g2.drawImage(img2,null,null);
			if (ca.sizeX!=sizeX) {
				img = new BufferedImage (ca.sizeX*ca.mag,ca.sizeY*ca.mag,BufferedImage.TYPE_INT_ARGB);
				ca.sizeX=sizeX;
			}
	}

	public void nextTimeStep ()
	{
		ca.nextTimeStep();
        if (timestep % 10 ==0){ //draw an image every 10 time steps
            paintAll();}
		timestep++;
	}
	

	public void paintAll()
	{
		int [][] lattice = ca.getCells();
		
		BufferedImage all = new BufferedImage (2*ca.sizeX,2*ca.sizeY,BufferedImage.TYPE_INT_ARGB);
		BufferedImage c= getCells();// this is the cells (inverted)
        BufferedImage t=getConcentration(ca.getTGFB()); //TGFB
        //BufferedImage a=getAge(ca.getAge()); //Age of bone
        BufferedImage r=getRemodeling(ca.getRemodeling()); //Remodeling field
        BufferedImage s=getRANKL(ca.getRANKL()); //RANKL
        
		for (int i=0;i<ca.sizeX;i++)
			for (int j=0;j<sizeY;j++) {
				all.setRGB(sizeX-i,sizeY-j,c.getRGB(i,j));
                all.setRGB(i+sizeX,j,t.getRGB(i,j));
                //all.setRGB(i,j+sizeY,a.getRGB(i,j));
                all.setRGB(i,j+sizeY,s.getRGB(i,j));
                
                all.setRGB(i+sizeX,j+sizeY,r.getRGB(i,j));
				img.setRGB(sizeX-i,sizeY-j,c.getRGB(i,j));
                img.setRGB(i+sizeX,j,t.getRGB(i,j));
               // img.setRGB(i,j+sizeY,a.getRGB(i,j));
                img.setRGB(i,j+sizeY,s.getRGB(i,j));
                
                img.setRGB(i+sizeX,j+sizeY,r.getRGB(i,j));
			}

		repaint();
		if (movie) try {
			File dir = new File (rootDir+"/images"+ca.seed);
			dir.mkdir ();
			File fileAll = new File (rootDir+"/images"+ca.seed+"/cell"+(counter*10)+".png");
			ImageIO.write(img,"png",fileAll);
		} catch (Exception e) {
			e.printStackTrace();
		}	

		counter++;
	}
    
    
    //gets TGFB release
    public BufferedImage getConcentration (float[][] lattice)
	{
		BufferedImage result = new BufferedImage (ca.sizeX,ca.sizeY,BufferedImage.TYPE_INT_ARGB);
		int k=0;
		for (int i=0;i<ca.sizeX;i++)
			for (int j=0;j<ca.sizeY;j++) {
				Color c1, c;
				c = new Color (255,255,255);
                
                
				if ((lattice[i][j]>=0) && (lattice[i][j]<=0.0001)) {
					c = new Color((int)(lattice[i][j]*255*10000), 0,  0);
                    //System.err.println ("RED "+lattice[i][j]);
                    
				} else if ((lattice[i][j]>0.0001) && (lattice[i][j]<=0.001)) {
					c = new Color(255, (int)(lattice[i][j]*255*1000),  0);
                    // System.err.println ("YELLOW "+lattice[i][j]);
                    
                    
				}else if ((lattice[i][j]>0.001) && (lattice[i][j]<=0.01)) {
					c = new Color(225, 255 ,  (int)(lattice[i][j]*255*100));
                   // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				} else if ((lattice[i][j]>0.01) && (lattice[i][j]<=0.1)) {
					c = new Color(0, (int)(lattice[i][j]*255*10) , 255 );
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				} else if ((lattice[i][j]>0.1) && (lattice[i][j]<=1)) {
					c = new Color((int)(lattice[i][j]*255), 255 ,  255);
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				}
                
                	else System.err.println ("not possible: "+lattice[i][j]);
				result.setRGB((ca.sizeX-i-1),(ca.sizeY-j-1),c.getRGB());
			}
		return result;
	}
    
    //gets Bone Remodeling factors
    public BufferedImage getRemodeling (float[][] lattice)
	{
		BufferedImage result = new BufferedImage (ca.sizeX,ca.sizeY,BufferedImage.TYPE_INT_ARGB);
		int k=0;
		for (int i=0;i<ca.sizeX;i++)
			for (int j=0;j<ca.sizeY;j++) {
				Color c1, c;
				c = new Color (255,255,255);
				if ((lattice[i][j]>=0) && (lattice[i][j]<=0.0001)) {
					c = new Color((int)(lattice[i][j]*255*10000), 0,  0);
                    //System.err.println ("RED "+lattice[i][j]);
                    
				} else if ((lattice[i][j]>0.0001) && (lattice[i][j]<=0.001)) {
					c = new Color(255, (int)(lattice[i][j]*255*1000),  0);
                    // System.err.println ("YELLOW "+lattice[i][j]);
                    
                    
				}else if ((lattice[i][j]>0.001) && (lattice[i][j]<=0.01)) {
					c = new Color(225, 255 ,  (int)(lattice[i][j]*255*100));
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				} else if ((lattice[i][j]>0.01) && (lattice[i][j]<=0.1)) {
					c = new Color(0, (int)(lattice[i][j]*255*10) , 255 );
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				} else if ((lattice[i][j]>0.1) && (lattice[i][j]<=1)) {
					c = new Color((int)(lattice[i][j]*255), 255 ,  255);
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				}
                
                else System.err.println ("not possible: "+lattice[i][j]);
				result.setRGB((ca.sizeX-i-1),(ca.sizeY-j-1),c.getRGB());
			}
		return result;
	}
    
    
    //gets RANKL release
    public BufferedImage getRANKL (float[][] lattice)
	{
		BufferedImage result = new BufferedImage (ca.sizeX,ca.sizeY,BufferedImage.TYPE_INT_ARGB);
		int k=0;
		for (int i=0;i<ca.sizeX;i++)
			for (int j=0;j<ca.sizeY;j++) {
				Color c1, c;
				c = new Color (255,255,255);
                
                
				if ((lattice[i][j]>=0) && (lattice[i][j]<=0.0001)) {
					c = new Color((int)(lattice[i][j]*255*10000), 0,  0);
                    //System.err.println ("RED "+lattice[i][j]);
                    
				} else if ((lattice[i][j]>0.0001) && (lattice[i][j]<=0.001)) {
					c = new Color(255, (int)(lattice[i][j]*255*1000),  0);
                    // System.err.println ("YELLOW "+lattice[i][j]);
                    
                    
				}else if ((lattice[i][j]>0.001) && (lattice[i][j]<=0.01)) {
					c = new Color(225, 255 ,  (int)(lattice[i][j]*255*100));
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				} else if ((lattice[i][j]>0.01) && (lattice[i][j]<=0.1)) {
					c = new Color(0, (int)(lattice[i][j]*255*10) , 255 );
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				} else if ((lattice[i][j]>0.1) && (lattice[i][j]<=1)) {
					c = new Color((int)(lattice[i][j]*255), 255 ,  255);
                    // System.err.println ("Blue "+lattice[i][j]);
                    
                    
				}
                
                else System.err.println ("not possible: "+lattice[i][j]);
				result.setRGB((ca.sizeX-i-1),(ca.sizeY-j-1),c.getRGB());
			}
		return result;
	}
    

    //gets Age of bone
	public BufferedImage getAge (int[][] lattice)
	{
		BufferedImage result = new BufferedImage (ca.sizeX,ca.sizeY,BufferedImage.TYPE_INT_ARGB);
		for (int i=0;i<ca.sizeX;i++)
			for (int j=0;j<ca.sizeY;j++) {
                //Reparametrize the bone age
				int val=(int) (lattice[i][j]);
                
                int val2 = (int) Math.ceil( (val*255.0/21600.0));
                
				if (val2>255) val2=255;
				Color c = new Color (val2,val2,val2);
				//result.setRGB(i,j,c.getRGB()); //unflipped
                result.setRGB((ca.sizeX-i-1),(ca.sizeY-j-1),c.getRGB());//flipped to match cells
			}
			return result;
	}

    //Osteoblast/osteoclast/bone interaction
	public BufferedImage getCells()
	{
		int [][] lattice = ca.getCells();
		BufferedImage result = new BufferedImage (ca.sizeX,ca.sizeY,BufferedImage.TYPE_INT_ARGB);
		
		for (int i=0;i<ca.sizeX;i++)
			for (int j=0;j<ca.sizeY;j++) {
				int val=0;
                
                
                if (lattice[i][j]==0) val=Color.white.getRGB();//Marrow -> ??
                else if (lattice[i][j]==1) val=Color.green.getRGB(); // pOB -> blue (cyan)
                else if (lattice[i][j]==2) val=Color.blue.getRGB(); // aOB -> purple (burgundy)
                else if (lattice[i][j]==3) val=Color.red.getRGB(); // pOC -> dark pink
                else if (lattice[i][j]==4) val=Color.red.getRGB(); // aOC -> red (maroon)
                else if (lattice[i][j]==5) val=(new Color(242, 209, 114)).getRGB(); // MSC
                else if (lattice[i][j]==6) val=(new Color(31, 30, 27)).getRGB(); // TRP
                else if (lattice[i][j]==7) val=(new Color(87, 82, 85)).getRGB(); // TR
                else if (lattice[i][j]==8) val=(new Color(128, 119, 123)).getRGB(); // TN
                else if (lattice[i][j]==9) val=(new Color(238, 196, 175)).getRGB(); // bone
                else if (lattice[i][j]==10) val=(new Color(171, 88, 103)).getRGB(); // canopy
                
                /*
				if (lattice[i][j]==0) val=(new Color(255, 255, 255)).getRGB();//Marrow
				else if (lattice[i][j]==1) val=(new Color(59, 153, 177)).getRGB(); // pOB
				else if (lattice[i][j]==2) val=(new Color(182, 58, 175)).getRGB(); // aOB
				else if (lattice[i][j]==3) val=(new Color(198, 126, 135)).getRGB(); // pOC
                else if (lattice[i][j]==4) val=(new Color(170, 32, 34)).getRGB(); // aOC
				else if (lattice[i][j]==5) val=(new Color(242, 209, 114)).getRGB(); // MSC
                else if (lattice[i][j]==6) val=(new Color(31, 30, 27)).getRGB(); // TRP
                else if (lattice[i][j]==7) val=(new Color(87, 82, 85)).getRGB(); // TR
                else if (lattice[i][j]==8) val=(new Color(128, 119, 123)).getRGB(); // TN
                else if (lattice[i][j]==9) val=(new Color(238, 196, 175)).getRGB(); // bone
                else if (lattice[i][j]==10) val=(new Color(171, 88, 103)).getRGB(); // canopy
                else if (lattice[i][j]==11) val=(new Color(155, 155, 155)).getRGB(); // odOB
                 
                 */
				result.setRGB(i,j,val);
			}
		return result;
	}
	
	
	public void actionPerformed (ActionEvent e) {
		String res = e.getActionCommand();
		if ("play".equals(e.getActionCommand())) {
			if (play) {
				play=false;
				button.setText ("Play");
			}
			else {
				play=true;
				button.setText ("Pause");
			}
		} 

		//else if (res.compareTo("A")==0) ca.drug=1;
        //else if (res.compareTo("B")==0) ca.drug=2;
        //else if (res.compareTo("AB")==0) ca.drug=3;
		else if (res.compareTo("Movie")==0) {
			if (movie==false) movie=true;
			else movie=false;
		//}
		//else if (res.compareTo("therapyButton")==0) {
		//	System.out.println ("I hear you!");
        //	} else { 
		}
		repaint();
	}
	public void mouseExited (MouseEvent e) {}	
	public void mouseEntered (MouseEvent e) {}
	public void mouseReleased (MouseEvent e) {}
	public void mousePressed (MouseEvent e) {}


	public static void main(String args[]) {
		int mag=2;
		int maxTS=60000;
		boolean movie;
	
		System.err.println ("# Vis version:"+Vis.version);
		System.err.println ("# CA version:"+CA.version);
		
		// Let's deal now with the main window
		JFrame f = new JFrame("CA Visualisation "+CA.version);
	        f.addWindowListener(new WindowAdapter() {
	        	public void windowClosing(WindowEvent e) {System.exit(0);}
	        });
		JLabel label = new JLabel ("Timesteps");
		
		
		JButton play = new JButton ("Pause");
		JCheckBox cb = new JCheckBox ("Movie",false);
		Vis m = new Vis (play,label,cb);
		play.setActionCommand("play");

		play.addActionListener (m);
		cb.addActionListener(m);
		JPanel buttonPanel = new JPanel(); //use FlowLayout
		buttonPanel.add(cb);
		buttonPanel.add(play);
	
		f.getContentPane().add("Center", m);
		f.getContentPane().add("North",label);
		f.getContentPane().add("South",buttonPanel);
		
		
		f.pack();
		f.setSize(new Dimension(2*m.ca.mag*m.sizeX,3*m.ca.mag*m.sizeY));
				//f.setSize(new Dimension(2*m.ca.mag*m.sizeX,1*m.ca.mag*m.sizeY+80));

		f.show();
		
		boolean finished=false;
		int ts=0;
		while (ts!=maxTS) {
			if (m.play) {
				m.nextTimeStep();
				label.setText ("Timestep: "+ts);
				ts++;
			}
		}
		System.exit(-1);
	}

}
